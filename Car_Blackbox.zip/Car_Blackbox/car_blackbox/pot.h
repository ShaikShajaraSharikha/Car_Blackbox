#ifndef POT_H
#define POT_H

static void init_config_pot(void);
unsigned short read_adc_value(void);
unsigned char *my_itoa ( unsigned short value);

#endif

#include "pic_specific.h"
#include "clcd.h"

extern unsigned char flag, trial;

void interrupt isr(void)
{
    static unsigned long count;
    if (TMR0IF)
    {
	TMR0 = TMR0 + 8;                                 //Timer0 with 8 bits size
    
	if ( count++ >= (2400000) )                      //Delay for 2mins and set flag for next entry
	{
	    count = 0;
	    flag = 1;
	    trial = '3';                                 //Set 3 trials and clear the screen
	    TMR0ON = 0;
	    CLEAR_DISP_SCREEN;
	}
	TMR0IF = 0;
    }
}

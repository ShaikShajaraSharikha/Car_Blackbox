#include "main.h"
#include "pic_specific.h"
#include "storage.h"
#include "delay.h"

void init_config_storage(void)                                                        //Initilizing function definition
{
    ADCON1 = 0x0F;                                                            //To make port as digital port
    init_ssd_control();                                                       //Initilizing ssd control function call
}

unsigned char eeprom_at24c04_write_log_entry(unsigned char mem_loc, unsigned char count, unsigned char *time, unsigned char *event, unsigned char *speed )
{
    unsigned char index = 0;
    eeprom_at24c04_byte_write(mem_loc++, count);
    while ( index < 8 )
    eeprom_at24c04_byte_write(mem_loc++, time[index++]);
    index = 0;
    while ( index < 2 )
    eeprom_at24c04_byte_write(mem_loc++, event[index++]);
    index = 0;
    while ( index < 2 )
    eeprom_at24c04_byte_write(mem_loc++, speed[index++]);
    return mem_loc;
}

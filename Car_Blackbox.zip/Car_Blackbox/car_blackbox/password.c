#include "pic_specific.h"
#include "password.h"
#include "storage.h"
#include "matrix_keypad.h"
#include "clcd.h"
#include "at24c04.h"
#include "timer0.h"

//Initialize matrix keypad and clcd
void init_config_password(void)
{
	//   PEIE = 1;
	/* Clear old content */
	PORTB = 0x00;

	/* Set PORTB as a Output */
	TRISB = 0x00;

	/* Config PORTB as digital */
	ADCON1 = 0x0F;

	init_timer0();

	GIE = 1;
	TMR0ON = 1;
	init_timer0();
	init_matrix_keypad();
	init_clcd();
}

extern unsigned char flag, trial, entry, block_entry, change_pass, password1[5], password2[5], p1, p2, once;
// function definition for password
void check_password(unsigned char *password, unsigned char key)
{
	static unsigned char pos = 5, index = 0, password_s[5], mem_loc = 0;
	unsigned long delay;

	if ( flag )
	{
		if ( !once )
			clcd_print("ENETR PASSWORD", LINE1(0));
		else
			clcd_print("RE-ENTER PASSWD", LINE2(0));
		if ( entry < 4 )
		{
			if ( key == 11 )                                                  //Display 0 if key1 is pressed
			{
				clcd_putch('*', LINE2(pos++));
				if ( !change_pass )
					password[entry] = '0';
				else if ( p1 < 4 )
				{
					password1[entry] = '0';
						eeprom_at24c04_byte_write(mem_loc++, password1[entry]);
				}
				else if ( p2 < 4 )
				{
					password2[entry] = '0';
				}
			}
			else if ( key == 12 )                                            //Display 1 if key2 is pressed
			{
				clcd_putch('*', LINE2(pos++));
				if ( !change_pass )
					password[entry] = '1';
				else if ( p1 < 4 )
				{
					password1[entry] = '1';
						eeprom_at24c04_byte_write(mem_loc, password1[entry]);
				}
				else if ( p2 < 4 )
				{
					password2[entry] = '0';
						eeprom_at24c04_byte_write(mem_loc, password2[entry]);
				}
			}
			for ( delay = 100000; delay--; );                            //Provide delay to read the error message
			entry++;
		}
		if ( p1 == 4 )
		{
			entry = 0;
			once = 1;
			p2 = 0;
		}
		if ( entry == 4 )
		{
			if ( !change_pass )
			{
				while ( index < 4 )
					password_s[index++] = eeprom_at24c04_random_read(mem_loc++);
				CLEAR_DISP_SCREEN;                                             //Clear display screen to print the next message
				if ( strcmp(password, password_s) == 0 )                        //Compare read password with right password
				{
					clcd_print("PASWD SUCCESSFULL", LINE1(0));
					flag = 0;
				}
				else                                                            //If false decrement the number of trials
				{
					clcd_print("PASWD UNSUCESFULL", LINE1(0));
					clcd_putch(--trial, LINE2(0));
					clcd_print(" trial remains", LINE2(1));

					for ( delay = 500000; delay--; );                            //Provide delay to read the error message

					CLEAR_DISP_SCREEN;                                           //Clear display screen to print the next message
					flag = 1;
					entry = 0;
					pos = 5;
				}
			}
			else
			{
				while ( index < 4 )
					password1[index++] = eeprom_at24c04_random_read(mem_loc++);
				CLEAR_DISP_SCREEN;                                             //Clear display screen to print the next message
                                if ( strcmp(password1, password2) == 0 )                        //Compare read password with right password
                                {
                                        clcd_print("PASSWORD CHANGED", LINE1(0));
                                        clcd_print("SUCCESSFULLY", LINE2(2));
                                        flag = 0;
                                }
                                else                                                            //If false decrement the number of trials
                                {
                                        clcd_print("PASSWORD NOT", LINE1(0));
                                        clcd_print("CHANGED", LINE2(3));
                                        for ( delay = 500000; delay--; );                            //Provide delay to read the error message
                                }

			}
		}
	}
	if ( !change_pass )
	{
	if ( trial == '0' )                                                   //Condition for trail 0 
	{
		CLEAR_DISP_SCREEN;
		flag = 1;
		block_entry = 1;
		clcd_print("ENTRY BLOCKED", LINE1(0));
		clcd_print("Try after 2 mins", LINE2(0));
		for ( delay = 5000; delay--; );
		TMR0ON = 1;
	}
	}
}

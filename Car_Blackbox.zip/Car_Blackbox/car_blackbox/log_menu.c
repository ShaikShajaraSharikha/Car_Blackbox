#include "log_menu.h"
#include "storage.h"
#include "matrix_keypad.h"

extern unsigned char change, pos, log[5][15];
extern unsigned char entry, password1[5], password2[5], mem_loc, pos_d;

void display_menu ( unsigned char key )
{
	CLEAR_DISP_SCREEN;
	if(key == 12 && change < 4 )
	{
		change++;
		if ( pos < 2 )
			pos++;
	}
	else if ( key == 11 && change > 0 )
	{
		change--;
		if ( pos > 1 )
			pos--;
	}
	if ( pos == 1 )
	{
		clcd_putch('*', LINE1(0));
		clcd_print(log[change], LINE1(2));
		clcd_print(log[change+1], LINE2(2));
	}
	else
	{
		clcd_putch('*', LINE2(0));
		clcd_print(log[change-1], LINE1(2));
		clcd_print(log[change], LINE2(2));
	}
}

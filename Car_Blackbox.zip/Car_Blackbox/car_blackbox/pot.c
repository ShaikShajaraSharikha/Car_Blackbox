#include "main.h"
#include "pic_specific.h"
#include "adc.h"

static void init_config_pot(void)
{
    init_adc();
}

unsigned short read_adc_value(void)
{
	//Read the adc value
	return read_adc(CHANNEL4);
}

unsigned char *my_itoa ( unsigned short value)
{
    unsigned char str[10], ch;
    unsigned char i = 0;
    unsigned char len = strlen(str);
    while ( value )
    {
	str[i] = ( value % 10 ) + '0';
	value = value / 10;
	i++;
    }
    str[i] = '\0';
    for ( i = 0; i < len/2; i++ )
    {
	ch = *(str + i);
	*(str + i) = *( str + len - i - 1 );
	*(str + len - i - 1) = ch;
    }
    return str;
}

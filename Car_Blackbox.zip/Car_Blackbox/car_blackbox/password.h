#ifndef PASSWORD_H
#define PASSWORD_H

#define SUCCESS    1
#define FAILURE    0

void init_config_password(void);
void check_password(unsigned char *, unsigned char);

#endif

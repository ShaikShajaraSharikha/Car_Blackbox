#ifndef TIME_H
#define TIME_H

#include "pic_specific.h"

void display_time(unsigned char *);
static void get_time(unsigned char *);
void init_config_time(void);

#endif

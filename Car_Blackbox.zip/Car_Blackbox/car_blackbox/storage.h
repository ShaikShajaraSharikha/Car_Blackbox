#ifndef EXT_STORAGE_H
#define EXT_STORAGE_H

#include "at24c04.h"
#include "pic_specific.h"

unsigned char eeprom_at24c04_write_log_entry(unsigned char mem_loc, unsigned char count, unsigned char *time, unsigned char *event, unsigned char *speed );

#endif

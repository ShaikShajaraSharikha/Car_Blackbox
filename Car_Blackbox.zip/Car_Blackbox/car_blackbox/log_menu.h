#ifndef LOG_H
#define LOG_H

#include "pic_specific.h"
#include "password.h"
#include "matrix_keypad.h"
#include "clcd.h"
#include "timer0.h"

void display_menu ( unsigned char );
void change_password ( unsigned char );

#endif

/* Documentation
Name:        Shaik Shajara Sharikha
Date:        04/03/2020
Description: The Car Back Box used to log all the critical events like gear shifts with current speed, engine temperature, etc.
             The system should allow a password based access to transport managers to view the log when required.
*/

#include "pic_specific.h"
#include "main.h"
#include "clcd.h"
#include "ds1307.h"
#include "i2c.h"
#include "adc.h"
#include "storage.h"
#include "time.h"
#include "matrix_keypad.h"
#include "pot.h"
#include "password.h"
#include "log_menu.h"

//declaration
static unsigned char event_ind0[] = {'R','N','1','2','3','4'};
unsigned char flag = 1, trial = '3', password[5], entry = 0, block_entry = 0, line1 = 0, line2 = 1, change = 0, pos = 1, mem_loc = 0, count = 0;
unsigned char log[5][15] = { "View log", "Download log", "Set Time", "Clear Log", "Passwd Change" }, time[9], index = 0, password[5] = "0101";
unsigned short ch = 0;
unsigned char flag_entry = 2, password1[5], password2[5], change_pass = 0, p1 = 0, p2 = 0, once = 0;

void init_config(void)
{
	init_config_time();
	init_config_switch();
	init_adc();
	init_config_password();
	clcd_print("Time     E   SP", LINE1(0));
	clcd_print("ON", LINE2(9));
}

void main(void)
{
	init_config();
	unsigned char key;
	unsigned char pre_key;
	unsigned char ind0 = 0;
	unsigned short adc_reg_val;
	unsigned char *str;
	unsigned long delay;
	unsigned char passwd, pass = 0, pass_entry = 0;
	while ( index < 5 )
	{
		eeprom_at24c04_byte_write(mem_loc, password[index++]);
		mem_loc++;
	}
	while (1)
	{
		if ( !pass_entry )
		{
			// for speed varing using adc pot here
			adc_reg_val = read_adc_value();
			str = my_itoa((int)(adc_reg_val/10.3));
			clcd_print(str, LINE2(13));
			// for displaying the time by using RTC
			display_time(time);
		}
		else if ( trial != '0' && flag == 1 )
		{
			clcd_print("ENTER PASSWORD", LINE1(0));
		}
		else if ( block_entry )
		{
			// for checking password
			check_password(password, key);
			block_entry = 0;
		}
		else if ( !flag )
		{
			// for entering the menu
			trial = '0', flag = 2;
			for ( delay = 500000; delay--; );
			CLEAR_DISP_SCREEN;
			clcd_putch('*', LINE1(0));
			clcd_print(log[0], LINE1(2));
			clcd_print(log[1], LINE2(2));
		}
		key = read_switches(STATE_CHANGE);
		switch ( key )
		{
			case 1 :
				if ( !pass_entry )
				{
					// for collision event shown by presing key 1
					clcd_putch('C', LINE2(9));
					clcd_putch(' ', LINE2(10));
					mem_loc = eeprom_at24c04_write_log_entry( mem_loc , count++, time, event_ind0, str );
				}
				break;
			case 2 :
				if ( !pass_entry )
				{
					clcd_putch('G', LINE2(9));
					if ( ind0 < 6 )
						// gear increases show by presing key 2
						clcd_putch(event_ind0[ind0++], LINE2(10));
					mem_loc = eeprom_at24c04_write_log_entry( mem_loc , count++, time, event_ind0, str );
				}
				break;
			case 3 :
				if ( !pass_entry )
				{
					clcd_putch('G', LINE2(9));
					if ( ind0 > 0 )
						// gear decreases shown by presing key 3
						clcd_putch(event_ind0[--ind0], LINE2(10));
					mem_loc = eeprom_at24c04_write_log_entry( mem_loc , count++, time, event_ind0, str );
				}
				break;
			case 11 :
			case 12 :
				if ( pass_entry == 0 )
				{
					CLEAR_DISP_SCREEN;
					pass_entry = 1;
					clcd_print("ENTER PASSWORD", LINE1(0));
				}
				else if ( flag == 2 )
				{
					display_menu(key);
				}
				else if ( flag == 1 )
				{
					check_password(password, key);
					for ( delay = 5000; delay--; );
				}
				else if ( flag == 3 )
				{
					 switch ( change )
                                {
                                        case 0 :
                                                view_log();
                                                break;
                                        case 1 :
                                                download_log();
                                                break;
                                        case 2 :
                                                set_time();
                                                break;
                                        case 3 :
                                                clear_log();
                                                break;
                                        case 4 :
                                                check_password(password, key);
                                }
				}
		}
		key = read_switches(LEVEL_CHANGE);
		if(key == MK_SW12)
		{
			if(ch++ > 50000)
			{
				ch = 0;
				flag = 3;
				CLEAR_DISP_SCREEN;
				entry = 0;
				mem_loc = 0;
				pos = 5;
			}
		}

	}
}
